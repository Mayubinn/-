//
//  Subject+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData


extension Subject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Subject> {
        return NSFetchRequest<Subject>(entityName: "Subject")
    }

    @NSManaged public var age: Int32
    @NSManaged public var name: String?
    @NSManaged public var teacher: String?
    @NSManaged public var username: String?
    @NSManaged public var college: College?
    @NSManaged public var data: NSSet?
    public var dataArray :[DataOfSubject]{
        return data?.allObjects as? [DataOfSubject] ?? []
    }

}

// MARK: Generated accessors for data
extension Subject {

    @objc(addDataObject:)
    @NSManaged public func addToData(_ value: DataOfSubject)

    @objc(removeDataObject:)
    @NSManaged public func removeFromData(_ value: DataOfSubject)

    @objc(addData:)
    @NSManaged public func addToData(_ values: NSSet)

    @objc(removeData:)
    @NSManaged public func removeFromData(_ values: NSSet)

}

extension Subject : Identifiable {

}
