//
//  User+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var password: String?
    @NSManaged public var username: String?
    @NSManaged public var loginuser: LoginUser?
    @NSManaged public var data: NSSet?
    
    public var dataArray :[DataOfSubject]{
        return data?.allObjects as? [DataOfSubject] ?? []
    }

}

// MARK: Generated accessors for data
extension User {

    @objc(addDataObject:)
    @NSManaged public func addToData(_ value: DataOfSubject)

    @objc(removeDataObject:)
    @NSManaged public func removeFromData(_ value: DataOfSubject)

    @objc(addData:)
    @NSManaged public func addToData(_ values: NSSet)

    @objc(removeData:)
    @NSManaged public func removeFromData(_ values: NSSet)

}

extension User : Identifiable {

}
