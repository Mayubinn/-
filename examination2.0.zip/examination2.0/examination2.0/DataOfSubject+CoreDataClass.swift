//
//  DataOfSubject+CoreDataClass.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData

@objc(DataOfSubject)
public class DataOfSubject: NSManagedObject {

}
