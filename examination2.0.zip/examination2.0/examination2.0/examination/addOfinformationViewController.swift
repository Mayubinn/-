//
//  addOfinformationViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class addOfinformationViewController: UIViewController {

    var login:[LoginUser]?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var allCollege:[College]?
    @IBOutlet weak var college: UITextField!
    
   
    @IBOutlet weak var Addbutton: UIButton!
    @IBOutlet weak var teacher: UITextField?
    @IBOutlet weak var age: UITextField?
    @IBOutlet weak var name: UITextField?

   
    @IBOutlet weak var updata: UITextField!
    
    override func viewDidLoad() {
    super.viewDidLoad()
    do{
            try login = context.fetch(LoginUser.fetchRequest())
        }
        catch{
            
    }

    
    // Do any additional setup after loading the view.
}
    @IBAction func close(_ sender: Any) {
        
        let newSubject = Subject(context: context)
        let newData = DataOfSubject(context: context)
        newData.data = updata?.text
        
        
        newSubject.name = name?.text
        newSubject.teacher  = teacher?.text
        
        newSubject.addToData(newData)
        login![0].user?.addToData(newData)
        
        
        let addCollege = college.text
        
        do{
                try self.allCollege = self.context.fetch(College.fetchRequest())
            }catch{
                
            }
            
            var f = 0
            for i in self.allCollege!{
                if(i.nameOfcollege == addCollege){
                    i.addToSubject(newSubject)
                    f = 1
                }
            }
            
            if(f == 0){
                let newCollege = College(context: self.context)
                
                newCollege.nameOfcollege = addCollege
                newCollege.addToSubject(newSubject)
            }
        
        do{
            try self.context.save()
        }
        catch{
            
        }

        self.dismiss(animated: false, completion: nil)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
