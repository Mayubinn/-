//
//  InformationViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class InformationViewController: UIViewController ,UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.informationOfAllData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = "科目：" +  (self.informationOfAllData?[indexPath.row].subject?.name)! + " 资料：" + (self.informationOfAllData?[indexPath.row].data)!
        
        
        return cell
    }
    
    var informtion :Subject!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var login:[LoginUser]?
    
    var item:[Subject]?
    var college:College?
    var informationOfAllData:[DataOfSubject]?
    

    @IBOutlet weak var informationTilte: UILabel?
    
    @IBOutlet weak var informationOfage: UILabel?
    
    @IBOutlet weak var name: UILabel?
    
    @IBOutlet weak var DataOfCollege: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        informationTilte?.text = informtion.college?.nameOfcollege
        
        informationOfage?.text = informtion.teacher
        name?.text = informtion.name
        
        do{
            try login = context.fetch(LoginUser.fetchRequest())
        }
        catch{
            
        }
        
        informationOfAllData = self.informtion.dataArray

        // Do any additional setup after loading the view.
        DataOfCollege.delegate = self
        DataOfCollege.dataSource = self
        
        fechMember()
        
    }
    
    func fechMember()  {
        do{
            self.informationOfAllData = self.informtion.dataArray
            DispatchQueue.main.async {
                self.DataOfCollege.reloadData()
            }
           
        }
        catch{
            
        }
    }
    
    func read(information1 : Subject)  {
        self.informtion = information1
    }
    
    
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
