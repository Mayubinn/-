//
//  UserLoginViewController.swift
//  examination
//
//  Created by ma on 2021/6/18.
//

import UIKit
import CoreData
class UserLoginViewController: UIViewController {

    var txtUser:UITextField!
    var txtPwd:UITextField!
    var btnLogin:UIButton!
    
   
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var item:[User]?
    
    
    var user:User!
    
    var user_login :[LoginUser]?
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let new_user_login = LoginUser(context: context)
        new_user_login.user?.username = "1"
        new_user_login.user?.password = "1"
        
        do{
            try context.save()
        }catch{
            
        }
        
        do{
            try user_login = context.fetch(LoginUser.fetchRequest())
        }
        catch{
            
        }
        
        
        
        let mainSize = UIScreen.main.bounds.size
        
        let vLogin = UIView(frame: CGRect(x: 30, y: 20, width: mainSize.width-60, height: 350))
        
        vLogin.layer.borderWidth = 0.5
        vLogin.layer.borderColor = UIColor.lightGray.cgColor
        vLogin.layer.cornerRadius = 5
        vLogin.backgroundColor = UIColor.white
        self.view.addSubview(vLogin) //把登录框界面添加到当前界面
        
        //用户输入
        txtUser = UITextField(frame: CGRect(x:30,y: 30,width: vLogin.frame.width,height: 44))
        txtUser.layer.cornerRadius = 5
        txtUser.layer.borderColor = UIColor.lightGray.cgColor
        txtUser.layer.borderWidth = 0.5
        txtUser.autocorrectionType = .no
        txtUser.leftView = UIView(frame: CGRect(x:0,y:0,width: 44,height: 44
        ))
        txtUser.leftViewMode = UITextField.ViewMode.always//图标是否一直显示
        
        
        //密码输入框
        txtPwd = UITextField(frame: CGRect(x:30,y:90,width: vLogin.frame.size.width, height: 44))
        txtPwd.layer.cornerRadius = 5
        txtPwd.layer.borderColor = UIColor.lightGray.cgColor
        txtPwd.layer.borderWidth = 0.5
        txtPwd.isSecureTextEntry = true   //输入的时候不显示具体字符，用 * 代替
        txtPwd.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 44, height: 44))
        txtPwd.leftViewMode = UITextField.ViewMode.always
        
        //密码左侧图标
        let imgPwd = UIImageView(frame: CGRect(x:11,y:11,width: 22,height: 22))
        imgPwd.image = UIImage(named: "iconfont-password")
        txtPwd.leftView!.addSubview(imgPwd)
        
        vLogin.addSubview(txtPwd)
        vLogin.addSubview(txtUser)
        
        //登陆确认按钮
        btnLogin = UIButton(frame: CGRect(x: (mainSize.width-60)/2, y: 150, width: 120, height:   50))
        btnLogin.setTitle("login", for: .normal)
        btnLogin.backgroundColor = UIColor.green
        btnLogin.addTarget(self, action: #selector(loginEvent), for:.touchUpInside )
        
        vLogin.addSubview(btnLogin)
    
        
    }
    
    @objc func loginEvent(){
        
        do{
         try self.item = context.fetch(User.fetchRequest())
            
        }
        catch{
        
        }
        
        let usercode = txtUser.text!
        let password = txtPwd.text!
        
        print(txtUser.text!)
        print(txtPwd.text!)
        
        txtUser.resignFirstResponder()
        
        txtPwd.resignFirstResponder()
        
        var truePassword :String!
    
        
        
        for i in  self.item! {
           
            if(i.username == (usercode)){
                truePassword = i.password!
               
                user = i
                break
            }
        }
        
        print(truePassword  == password)
        if(truePassword  == password){
            let mainBoard:UIStoryboard! = UIStoryboard(name: "Main", bundle: nil)
        
            let VCMain = mainBoard!.instantiateViewController(withIdentifier: "vcMain")
           
            self.user_login![0].user = user
            
            do{
                try context.save()
            }catch{
                
            }
            
            UIApplication.shared.windows[0].rootViewController = VCMain
            
            
        }else{
            let p=UIAlertController(title: "登陆失败", message: "用户名或密码错误", preferredStyle: .alert)
            p.addAction(UIAlertAction(title:"确定",style: .default,handler: {(act:UIAlertAction) in self.txtPwd.text = ""}))
           
            present(p, animated: false, completion: nil)
        }
    }
            
        
}
