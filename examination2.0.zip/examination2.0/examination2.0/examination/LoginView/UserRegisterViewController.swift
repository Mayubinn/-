//
//  UserRegisterViewController.swift
//  examination
//
//  Created by ma on 2021/6/18.
//

import UIKit

class UserRegisterViewController: UIViewController {

    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var item:[User]?
    
    @IBOutlet var txtUser :UITextField!
    @IBOutlet var txtPwd :UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtUser.layer.cornerRadius = 5
        txtUser.layer.borderColor = UIColor.lightGray.cgColor
        txtUser.layer.borderWidth = 0.5
        txtUser.autocorrectionType = .no
        txtUser.leftView = UIView(frame: CGRect(x:0,y:0,width: 44,height: 44
        ))
        txtUser?.leftViewMode = UITextField.ViewMode.always//图标是否一直显示
        
        
        txtPwd.layer.cornerRadius = 5
        txtPwd.layer.borderColor = UIColor.lightGray.cgColor
        txtPwd.layer.borderWidth = 0.5
          //输入的时候不显示具体字符，用 * 代替
        txtPwd.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 44, height: 44))
        txtPwd.leftViewMode = UITextField.ViewMode.always
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func OkPress(_sender :Any){
        
        let newUser = User(context: self.context)
        
        newUser.username = String(txtUser.text ?? "")
        newUser.password = String(txtPwd.text ?? "")
    
        
        do{
            try self.context.save()
        }
        catch{
            
        }
        
        self.dismiss(animated: false, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

