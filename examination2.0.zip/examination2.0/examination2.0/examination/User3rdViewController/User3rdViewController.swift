//
//  User3rdViewController.swift
//  examination
//
//  Created by ma on 2021/6/18.
//

import UIKit

class User3rdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func login3rd(_sender : UIButton){
        let p = UIAlertController(title: "第三方登录", message: nil, preferredStyle: .actionSheet)
                //下面添加三个选项，*********注意比较 3个 style的不同**********
                p.addAction(UIAlertAction(title: "QQ", style: .default, handler: nil))
                p.addAction(UIAlertAction(title: "信息门户", style: .destructive, handler: nil))
                p.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
        
                //以模态方式呈现出第三方登录选项窗口
                self.present(p, animated: false, completion: nil)
       
        
    }
    
    @IBAction func close(_sender : UIButton){
        self.dismiss(animated: false, completion: nil)
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
