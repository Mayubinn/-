//
//  LoginUser+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/18.
//
//

import Foundation
import CoreData


extension LoginUser {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<LoginUser> {
        return NSFetchRequest<LoginUser>(entityName: "LoginUser")
    }

    @NSManaged public var user: User?

}

extension LoginUser : Identifiable {

}
