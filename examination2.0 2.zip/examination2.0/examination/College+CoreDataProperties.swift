//
//  College+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData


extension College {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<College> {
        return NSFetchRequest<College>(entityName: "College")
    }

    @NSManaged public var nameOfcollege: String?
    @NSManaged public var subject: NSSet?
    @NSManaged public var user: NSSet?

    public var dataUser :[User]{
            return user?.allObjects as? [User] ?? []
    }
    public var subjectArray :[Subject]{
        return subject?.allObjects as? [Subject] ?? []
    }
}

// MARK: Generated accessors for subject
extension College {

    @objc(addSubjectObject:)
    @NSManaged public func addToSubject(_ value: Subject)

    @objc(removeSubjectObject:)
    @NSManaged public func removeFromSubject(_ value: Subject)

    @objc(addSubject:)
    @NSManaged public func addToSubject(_ values: NSSet)

    @objc(removeSubject:)
    @NSManaged public func removeFromSubject(_ values: NSSet)

}

// MARK: Generated accessors for user
extension College {

    @objc(addUserObject:)
    @NSManaged public func addToUser(_ value: User)

    @objc(removeUserObject:)
    @NSManaged public func removeFromUser(_ value: User)

    @objc(addUser:)
    @NSManaged public func addToUser(_ values: NSSet)

    @objc(removeUser:)
    @NSManaged public func removeFromUser(_ values: NSSet)

}

extension College : Identifiable {

}
