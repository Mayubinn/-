//
//  LoginUser+CoreDataClass.swift
//  examination
//
//  Created by ma on 2021/6/18.
//
//

import Foundation
import CoreData

@objc(LoginUser)
public class LoginUser: NSManagedObject {

}
