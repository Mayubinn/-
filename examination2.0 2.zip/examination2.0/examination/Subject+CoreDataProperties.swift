//
//  Subject+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData


extension Subject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Subject> {
        return NSFetchRequest<Subject>(entityName: "Subject")
    }
    

    @NSManaged public var age: Int32
    @NSManaged public var name: String?
    @NSManaged public var teacher: String?
    @NSManaged public var username: String?
    @NSManaged public var college: College?
    @NSManaged public var data: NSSet?
    @NSManaged public var user: NSSet?

    public var dataArray :[DataOfSubject]{
            return data?.allObjects as? [DataOfSubject] ?? []
        }
    public var dataUser :[User]{
            return user?.allObjects as? [User] ?? []
        }

}

// MARK: Generated accessors for data
extension Subject {

    @objc(addDataObject:)
    @NSManaged public func addToData(_ value: DataOfSubject)

    @objc(removeDataObject:)
    @NSManaged public func removeFromData(_ value: DataOfSubject)

    @objc(addData:)
    @NSManaged public func addToData(_ values: NSSet)

    @objc(removeData:)
    @NSManaged public func removeFromData(_ values: NSSet)

}

// MARK: Generated accessors for user
extension Subject {

    @objc(addUserObject:)
    @NSManaged public func addToUser(_ value: User)

    @objc(removeUserObject:)
    @NSManaged public func removeFromUser(_ value: User)

    @objc(addUser:)
    @NSManaged public func addToUser(_ values: NSSet)

    @objc(removeUser:)
    @NSManaged public func removeFromUser(_ values: NSSet)

}

extension Subject : Identifiable {

}
