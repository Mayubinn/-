//
//  DataOfSubject+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData


extension DataOfSubject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DataOfSubject> {
        return NSFetchRequest<DataOfSubject>(entityName: "DataOfSubject")
    }

    @NSManaged public var data: String?
    @NSManaged public var subject: Subject?
    @NSManaged public var updataOfUser: User?

}

extension DataOfSubject : Identifiable {

}
