//
//  TitleViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class TitleViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var login:[LoginUser]?
    
    var item:[Subject]?
    var college:College?
    var informationOfAllData:[DataOfSubject]?
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.informationOfAllData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let action = UIContextualAction(style: .destructive, title: "Delete"){
            (action,view, completionHandler) in
        let peronTomove = self.informationOfAllData![indexPath.row]
            
        self.context.delete(peronTomove)
            
            
        do{
                try self.context.save()
            }
            catch{
                
            }
            self.fechMember()
            
            
        }
        return UISwipeActionsConfiguration(actions:[action])
        
    }
   
   
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell()
      
        cell.textLabel?.text = "科目：" +  (self.informationOfAllData?[indexPath.row].subject?.name)! + " 资料：" +  (self.informationOfAllData?[indexPath.row].data)!
        
        
        return cell
    }
    
    
   
    
    @IBOutlet weak var informatinOfmember: UITableView!
    @IBAction func Add(_ sender: Any) {
       let addview = addOfinformationViewController()
        present(addview, animated: true, completion: nil)
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            try login = context.fetch(LoginUser.fetchRequest())
        }
        catch{
            
        }
        let User = login![0].user
        
        informationOfAllData = User?.dataArray

        // Do any additional setup after loading the view.
        informatinOfmember.delegate = self
        informatinOfmember.dataSource = self
        
        fechMember()
    }
    
    
    @IBAction func new(_ sender: Any) {
        fechMember()
        
    }
    
    func fechMember()  {
        do{
            self.informationOfAllData = self.login![0].user?.dataArray
            DispatchQueue.main.async {
                self.informatinOfmember.reloadData()
            }
           
        }
        catch{
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

