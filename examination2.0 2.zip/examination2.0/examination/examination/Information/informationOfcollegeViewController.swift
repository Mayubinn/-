//
//  informationOfcollegeViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class informationOfcollegeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var item:[Subject]?
    var college:College?
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.item?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell()
        cell.textLabel?.text = self.college?.subjectArray[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let person = self.item![indexPath.row]
        
        let arlert = UIAlertController(title: person.name, message: String(person.age), preferredStyle: .alert)
        
        let OKButton = UIAlertAction(title: "OK", style: .default){
            (action) in
            
        }
        
        
        arlert.addAction(OKButton)
        let informatinOfmember = InformationViewController()
        
        informatinOfmember.read(information1: person)
        show(informatinOfmember, sender: nil)
        
    }
    
   
    
    @IBOutlet weak var informatinOfmember: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
        informatinOfmember.delegate = self
        informatinOfmember.dataSource = self
        fechMember()
        
    
    }
    
    
    func getCollege(college1:College)  {
    
        self.college = college1
        self.item = self.college?.subjectArray
        
    }
    
    func fechMember()  {
        do{
            self.item = self.college?.subjectArray
            
            DispatchQueue.main.async {
                self.informatinOfmember.reloadData()
            }
           
        }
        catch{
            
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
