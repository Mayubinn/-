//
//  LoginViewController.swift
//  examination
//
//  Created by ma on 2021/6/18.
//

import UIKit
//登录,注册,第三方登录界面
class LoginViewController: UIViewController {
    //登录按键
    @IBAction func LoginPressed(_ sender:UIButton){
         let loginVC = UserLoginViewController()
//
       present(loginVC, animated: true, completion: nil) }
    //第三方登录按键
   @IBAction func Login3rdPressed(_ sender:UIButton){
      let login3rdVC = User3rdViewController()
          present(login3rdVC, animated: true, completion: nil)
   }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
