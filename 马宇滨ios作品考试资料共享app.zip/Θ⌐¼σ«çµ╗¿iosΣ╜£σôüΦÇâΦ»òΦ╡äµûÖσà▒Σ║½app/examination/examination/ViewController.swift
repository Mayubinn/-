//
//  ViewController.swift
//  examination
//
//  Created by ma on 2021/6/18.
//

import UIKit

class ViewController: UIViewController {

    var user:User?
    
    var login:[LoginUser]?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    @IBOutlet weak var informationOfuserName: UILabel?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        do{
            try login = context.fetch(LoginUser.fetchRequest())
        }
        catch{
            
        }
        
        informationOfuserName?.text = login![0].user?.username
    }

    @IBAction func close(_sender:UIButton){
        let loginBoard:UIStoryboard! = UIStoryboard(name: "Login", bundle: nil)
        
        let loginVC = loginBoard!.instantiateViewController(withIdentifier: "vcLogin")
        UIApplication.shared.windows[0].rootViewController = loginVC
        
    }
}



