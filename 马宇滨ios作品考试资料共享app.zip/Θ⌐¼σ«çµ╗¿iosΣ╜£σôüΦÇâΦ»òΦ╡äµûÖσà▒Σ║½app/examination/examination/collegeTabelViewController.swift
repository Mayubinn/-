//
//  collegeTabelViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class collegeTabelViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var myTableView:UITableView!
    
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var item:[Subject]?
    
    var  allCollege:[College]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTableView.dataSource = self
        myTableView.delegate = self
        
        fechMember()
        
    
    }
    
    @IBAction func addTapped(_ sender: Any){
        
        let arlert = UIAlertController(title: "addName", message: "hi", preferredStyle: .alert)

        arlert.addTextField()
        
        let submitButton = UIAlertAction(title: "Add", style: .default){ (action) in
            
        let textFied = arlert.textFields![0]
        let addCollege = "A"
            
            
        let newPeople = Subject(context: self.context)
            newPeople.name = textFied.text
            
            
        do{
                try self.allCollege = self.context.fetch(College.fetchRequest())
            }catch{
                
            }
            
            var f = 0
            for i in self.allCollege!{
                if(i.nameOfcollege == addCollege){
                    i.addToSubject(newPeople)
                    f = 1
                }
            }
            
            if(f == 0){
                let newCollege = College(context: self.context)
                
                newCollege.nameOfcollege = addCollege
                newCollege.addToSubject(newPeople)
                
            }
            
          
            
          //save
            do{
                try self.context.save()
            }
            catch{
                
            }
            self.fechMember()
            
            
        }
        arlert.addAction(submitButton)
        
        self.present(arlert, animated: true, completion: nil)
    }
   
  
    
    func fechMember()  {
        do{
            try  self.item = context.fetch(Subject.fetchRequest())
            try  self.allCollege = context.fetch(College.fetchRequest())
            
            DispatchQueue.main.async {
                self.myTableView.reloadData()
            }
           
        }
        catch{
            
        }
    }

    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.allCollege?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell",for: indexPath)
        
//        let newMember = Member(context: self.context)
//        newMember.age = 18
//        newMember.name = "hi"
//        do{
//           try self.context.save()
//        }
//        catch{
//
//        }
        
        
        let college = self.allCollege![indexPath.row]
        
        cell.textLabel?.text = college.nameOfcollege
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//            let person = self.item![indexPath.row]
        let college = self.allCollege![indexPath.row]
        
//            let arlert = UIAlertController(title: person.name, message: String(person.age), preferredStyle: .alert)
//
//            let OKButton = UIAlertAction(title: "OK", style: .default){
//                (action) in
//
//            }
        
//          arlert.addAction(OKButton)
        
        
        let login3rdVC = informationOfcollegeViewController()
        login3rdVC.getCollege(college1: college)
       
        show(login3rdVC, sender: nil)
        
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let action = UIContextualAction(style: .destructive, title: "Delete"){
            (action,view, completionHandler) in
            let college = self.allCollege![indexPath.row]
            
            self.context.delete(college)
            
            
            do{
                try self.context.save()
            }
            catch{
                
            }
            self.fechMember()
            
            
            
            
        }
        return UISwipeActionsConfiguration(actions:[action])
        
    }
   
    
    

   
}

