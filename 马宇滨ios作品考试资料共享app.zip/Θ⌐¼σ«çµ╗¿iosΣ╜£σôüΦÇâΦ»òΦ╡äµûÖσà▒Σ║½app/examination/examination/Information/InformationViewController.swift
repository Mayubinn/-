//
//  InformationViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class InformationViewController: UIViewController {
    var informtion :Subject!
    

    @IBOutlet weak var informationTilte: UILabel?
    
    @IBOutlet weak var informationOfage: UILabel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        informationTilte?.text = informtion.name
        
        informationOfage?.text = informtion.age
        
        
    }
    
    func read(information1 : Subject)  {
        self.informtion = information1
        
        
    }
    
    
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
