//
//  TableViewController.swift
//  examination
//
//  Created by ma on 2021/6/19.
//

import UIKit

class TableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var myTableView:UITableView!
    
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var item:[Subject]?
    
    var  allCollege:[College]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTableView.dataSource = self
        myTableView.delegate = self
        
        fechMember()
    
    }
    
    @IBAction func addTapped(_ sender: Any){
        
        let arlert = UIAlertController(title: "addName", message: "hi", preferredStyle: .alert)

        arlert.addTextField()
        
        
        
        let submitButton = UIAlertAction(title: "Add", style: .default){ (action) in
            
        let textFied = arlert.textFields![0]
        let addCollege = "A"
            
            
        let newPeople = Subject(context: self.context)
            newPeople.name = textFied.text
           
            
        do{
                try self.allCollege = self.context.fetch(College.fetchRequest())
            }catch{
                
            }
            
            var f = 0
            for i in self.allCollege!{
                if(i.nameOfcollege == addCollege){
                    i.addToSubject(newPeople)
                    f = 1
                }
            }
            
            if(f == 0){
                let newCollege = College(context: self.context)
                
                newCollege.nameOfcollege = addCollege
                newCollege.addToSubject(newPeople)
                
            }
            
          
          //save
            do{
                try self.context.save()
            }
            catch{
                
            }
            
            self.fechMember()
            
            
        }
        arlert.addAction(submitButton)
        
        let addView = addOfinformationViewController()
       show(addView, sender: nil)
        self.fechMember()
       
    }
   
  
    
    func fechMember()  {
        do{
            try  self.item = context.fetch(Subject.fetchRequest())
            
            DispatchQueue.main.async {
                self.myTableView.reloadData()
            }
           
        }
        catch{
            
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.item?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell",for: indexPath)
        
//        let newMember = Member(context: self.context)
//        newMember.age = 18
//        newMember.name = "hi"
//        do{
//           try self.context.save()
//        }
//        catch{
//
//        }
        
        
        let Member = self.item![indexPath.row]
        
        cell.textLabel?.text = Member.name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let person = self.item![indexPath.row]
        
        let arlert = UIAlertController(title: person.name, message: person.age, preferredStyle: .alert)
        
        let OKButton = UIAlertAction(title: "OK", style: .default){
            (action) in
            
        }
        
        
        arlert.addAction(OKButton)
        let login3rdVC = InformationViewController()
        
        login3rdVC.read(information1: person)
        show(login3rdVC, sender: nil)
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let action = UIContextualAction(style: .destructive, title: "Delete"){
            (action,view, completionHandler) in
            let peronTomove = self.item![indexPath.row]
            
            self.context.delete(peronTomove)
            
            
            do{
                try self.context.save()
            }
            catch{
                
            }
            self.fechMember()
            
            
            
            
        }
        return UISwipeActionsConfiguration(actions:[action])
        
    }
   
    
    

   
}
