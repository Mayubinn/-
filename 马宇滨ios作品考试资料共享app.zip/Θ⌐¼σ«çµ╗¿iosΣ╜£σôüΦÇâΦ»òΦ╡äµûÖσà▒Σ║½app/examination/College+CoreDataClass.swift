//
//  College+CoreDataClass.swift
//  examination
//
//  Created by ma on 2021/6/18.
//
//

import Foundation
import CoreData

@objc(College)
public class College: NSManagedObject {

}
