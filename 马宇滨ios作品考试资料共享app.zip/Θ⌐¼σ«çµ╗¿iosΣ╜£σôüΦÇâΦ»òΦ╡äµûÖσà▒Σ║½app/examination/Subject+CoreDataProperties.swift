//
//  Subject+CoreDataProperties.swift
//  examination
//
//  Created by ma on 2021/6/19.
//
//

import Foundation
import CoreData


extension Subject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Subject> {
        return NSFetchRequest<Subject>(entityName: "Subject")
    }

    @NSManaged public var age: String?
    @NSManaged public var name: String?
    @NSManaged public var teacher: String?
    @NSManaged public var username: String?
    @NSManaged public var college: College?

}

extension Subject : Identifiable {

}
